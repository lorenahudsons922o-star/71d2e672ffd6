// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("1k publishers, QoS 1"); }
int main(){
  announce();
  return lionss_run_workload("mqtt-broker-bench");
}
