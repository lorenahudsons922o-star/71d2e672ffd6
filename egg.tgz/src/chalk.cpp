// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Balance 400 tests into 8 shards"); }
int main(){
  announce();
  return lionss_run_workload("chalk");
}
