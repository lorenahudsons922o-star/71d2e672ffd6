// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Minimize rehandles"); }
int main(){
  announce();
  return lionss_run_workload("crane_seq");
}
