// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("5k rps unary for 60 s"); }
int main(){
  announce();
  return lionss_run_workload("aspen3");
}
