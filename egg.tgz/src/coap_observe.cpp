// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Observe 3 resources, 100 clients");
  std::fflush(stdout);
  return lionss_run_workload("coap_observe");
}
