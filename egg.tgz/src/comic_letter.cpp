// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Place balloons, avoid faces\n", stdout);
  return lionss_run_workload("comic_letter");
}
