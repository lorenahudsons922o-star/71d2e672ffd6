// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Form 5v5 lobbies, max spread 120"); }
int main(){
  announce();
  return lionss_run_workload("mmr-queue");
}
