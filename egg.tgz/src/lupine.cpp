// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Dose calculation, 5 beams\n", stdout);
  return lionss_run_workload("lupine");
}
