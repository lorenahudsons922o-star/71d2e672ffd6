// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Emit SPDX 2.3 document\n", stdout);
  return lionss_run_workload("sbomspdx");
}
