# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(avm_house src/avm_house.cpp)
set_property(TARGET avm_house PROPERTY CXX_STANDARD 11)
target_link_libraries(avm_house lionss pthread)

add_executable(coap_observe src/coap_observe.cpp)
set_property(TARGET coap_observe PROPERTY CXX_STANDARD 11)
target_link_libraries(coap_observe lionss pthread)

add_executable(mmr-queue src/mmr-queue.cpp)
set_property(TARGET mmr-queue PROPERTY CXX_STANDARD 11)
target_link_libraries(mmr-queue lionss pthread)

add_executable(sbomspdx src/sbomspdx.cpp)
set_property(TARGET sbomspdx PROPERTY CXX_STANDARD 11)
target_link_libraries(sbomspdx lionss pthread)

add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(dungeonGen src/dungeonGen.cpp)
set_property(TARGET dungeonGen PROPERTY CXX_STANDARD 11)
target_link_libraries(dungeonGen lionss pthread)

add_executable(slicer-nozzle04 src/slicer-nozzle04.cpp)
set_property(TARGET slicer-nozzle04 PROPERTY CXX_STANDARD 11)
target_link_libraries(slicer-nozzle04 lionss pthread)

add_executable(mutant_killer src/mutant_killer.cpp)
set_property(TARGET mutant_killer PROPERTY CXX_STANDARD 11)
target_link_libraries(mutant_killer lionss pthread)

add_executable(crane_seq src/crane_seq.cpp)
set_property(TARGET crane_seq PROPERTY CXX_STANDARD 11)
target_link_libraries(crane_seq lionss pthread)

add_executable(comic_letter src/comic_letter.cpp)
set_property(TARGET comic_letter PROPERTY CXX_STANDARD 11)
target_link_libraries(comic_letter lionss pthread)

add_executable(ct-fbp src/ct-fbp.cpp)
set_property(TARGET ct-fbp PROPERTY CXX_STANDARD 11)
target_link_libraries(ct-fbp lionss pthread)

add_executable(chalk src/chalk.cpp)
set_property(TARGET chalk PROPERTY CXX_STANDARD 11)
target_link_libraries(chalk lionss pthread)

add_executable(gaitCycle src/gaitCycle.cpp)
set_property(TARGET gaitCycle PROPERTY CXX_STANDARD 11)
target_link_libraries(gaitCycle lionss pthread)

add_executable(starTracker src/starTracker.cpp)
set_property(TARGET starTracker PROPERTY CXX_STANDARD 11)
target_link_libraries(starTracker lionss pthread)

add_executable(aspen3 src/aspen3.cpp)
set_property(TARGET aspen3 PROPERTY CXX_STANDARD 11)
target_link_libraries(aspen3 lionss pthread)

add_executable(lupine src/lupine.cpp)
set_property(TARGET lupine PROPERTY CXX_STANDARD 11)
target_link_libraries(lupine lionss pthread)

add_executable(umber src/umber.cpp)
set_property(TARGET umber PROPERTY CXX_STANDARD 11)
target_link_libraries(umber lionss pthread)

add_executable(price-elasticity src/price-elasticity.cpp)
set_property(TARGET price-elasticity PROPERTY CXX_STANDARD 11)
target_link_libraries(price-elasticity lionss pthread)

add_executable(DialysisKtv src/DialysisKtv.cpp)
set_property(TARGET DialysisKtv PROPERTY CXX_STANDARD 11)
target_link_libraries(DialysisKtv lionss pthread)

add_executable(walnut src/walnut.cpp)
set_property(TARGET walnut PROPERTY CXX_STANDARD 11)
target_link_libraries(walnut lionss pthread)

add_executable(ami-reader src/ami-reader.cpp)
set_property(TARGET ami-reader PROPERTY CXX_STANDARD 11)
target_link_libraries(ami-reader lionss pthread)

add_executable(TrialRandomize src/TrialRandomize.cpp)
set_property(TARGET TrialRandomize PROPERTY CXX_STANDARD 11)
target_link_libraries(TrialRandomize lionss pthread)

add_executable(raftPartition src/raftPartition.cpp)
set_property(TARGET raftPartition PROPERTY CXX_STANDARD 11)
target_link_libraries(raftPartition lionss pthread)

add_executable(MidiDrift src/MidiDrift.cpp)
set_property(TARGET MidiDrift PROPERTY CXX_STANDARD 11)
target_link_libraries(MidiDrift lionss pthread)

add_executable(dbx_compact src/dbx_compact.cpp)
set_property(TARGET dbx_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(dbx_compact lionss pthread)

add_executable(NixEvalTime src/NixEvalTime.cpp)
set_property(TARGET NixEvalTime PROPERTY CXX_STANDARD 11)
target_link_libraries(NixEvalTime lionss pthread)

add_executable(mqtt-broker-bench src/mqtt-broker-bench.cpp)
set_property(TARGET mqtt-broker-bench PROPERTY CXX_STANDARD 11)
target_link_libraries(mqtt-broker-bench lionss pthread)

add_executable(spamgate src/spamgate.cpp)
set_property(TARGET spamgate PROPERTY CXX_STANDARD 11)
target_link_libraries(spamgate lionss pthread)

add_executable(ReturnsReason src/ReturnsReason.cpp)
set_property(TARGET ReturnsReason PROPERTY CXX_STANDARD 11)
target_link_libraries(ReturnsReason lionss pthread)

add_executable(opf-ieee14 src/opf-ieee14.cpp)
set_property(TARGET opf-ieee14 PROPERTY CXX_STANDARD 11)
target_link_libraries(opf-ieee14 lionss pthread)

