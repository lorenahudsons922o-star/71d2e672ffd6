// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Hedonic valuation\n", stdout);
  return lionss_run_workload("avm_house");
}
