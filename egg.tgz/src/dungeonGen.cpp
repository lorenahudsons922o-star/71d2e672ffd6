// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Generate 50 rooms, BSP"); }
int main(){
  announce();
  return lionss_run_workload("dungeonGen");
}
