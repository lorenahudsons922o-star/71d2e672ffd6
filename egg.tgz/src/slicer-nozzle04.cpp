// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Slice at 0.2mm layers\n", stdout);
  return lionss_run_workload("slicer-nozzle04");
}
