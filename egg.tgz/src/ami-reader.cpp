// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Validate, estimate, edit (VEE)"); }
int main(){
  announce();
  return lionss_run_workload("ami-reader");
}
