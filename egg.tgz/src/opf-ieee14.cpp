// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("AC optimal power flow"); }
int main(){
  announce();
  return lionss_run_workload("opf-ieee14");
}
