// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Segment strides and cadence\n", stdout);
  return lionss_run_workload("gaitCycle");
}
