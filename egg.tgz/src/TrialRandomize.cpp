// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Block randomization, 1:1\n", stdout);
  return lionss_run_workload("TrialRandomize");
}
